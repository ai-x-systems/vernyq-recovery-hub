export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export const faqData: FaqItem[] = [
  // Products
  {
    id: "what-is-vernyc",
    question: "What is the VERNYQ V1?",
    answer:
      "The VERNYQ V1 is a premium all-in-one cold plunge system designed for home use. It includes an insulated tub, integrated cooling chiller, filtration system, and UV sterilization — everything you need for consistent cold water immersion recovery.",
    category: "Products",
  },
  {
    id: "v1-vs-v1-pro",
    question: "What's the difference between the V1 and V1 Pro?",
    answer:
      "The V1 Pro features a larger 400L capacity, a more powerful 1.0 HP chiller, dual-stage filtration with activated carbon, hydraulic-assist cover, and built-in Wi-Fi temperature monitoring. It also comes with an extended 2-year warranty.",
    category: "Products",
  },
  {
    id: "what-is-included",
    question: "What's included with my purchase?",
    answer:
      "Each VERNYQ system includes the cold plunge tub, integrated chiller, filtration system, UV sterilization module, insulated cover, drainage adapter, setup guide, and manufacturer warranty. No additional accessories are required.",
    category: "Products",
  },
  {
    id: "dimensions-fit",
    question: "Will the VERNYQ V1 fit in my space?",
    answer:
      "The V1 measures 180 cm × 80 cm × 75 cm (71\" × 31\" × 30\"). We recommend at least 30 cm (12\") of clearance on all sides for ventilation and maintenance. Measure your intended space and compare with our specifications.",
    category: "Products",
  },
  // Cold Plunging
  {
    id: "what-temp",
    question: "What temperature should I set my cold plunge to?",
    answer:
      "Most users find 3°C – 10°C (37°F – 50°F) effective for recovery. Beginners should start at the higher end and gradually lower the temperature as they adapt. Listen to your body and consult a healthcare provider if you have concerns.",
    category: "Cold Plunging",
  },
  {
    id: "how-often",
    question: "How often should I cold plunge?",
    answer:
      "Many users benefit from 2–4 sessions per week, but frequency depends on your goals, training load, and personal tolerance. Consistency matters more than intensity. Start with what feels manageable and build from there.",
    category: "Cold Plunging",
  },
  {
    id: "how-long",
    question: "How long should each session last?",
    answer:
      "Sessions of 2–5 minutes are common for recovery purposes. Some users extend to 10–15 minutes. The key is maintaining a consistent temperature rather than pushing for extreme duration.",
    category: "Cold Plunging",
  },
  // Setup
  {
    id: "setup-time",
    question: "How long does setup take?",
    answer:
      "Setup typically takes 30–60 minutes. Connect the drainage adapter, fill with water, plug in, and set your target temperature. The chiller will bring water to temperature in 2–6 hours depending on ambient conditions.",
    category: "Setup",
  },
  {
    id: "power-requirement",
    question: "What power does the V1 require?",
    answer:
      "The V1 uses a standard 110V / 60Hz outlet — the same as most household appliances in the US. No special electrical work is required. We recommend a dedicated circuit to avoid sharing with high-draw appliances.",
    category: "Setup",
  },
  {
    id: "where-to-place",
    question: "Where should I place my cold plunge?",
    answer:
      "The V1 can be placed indoors or outdoors on a flat, level surface. Ensure adequate drainage nearby, access to a power outlet, and at least 30 cm of clearance around the unit for ventilation.",
    category: "Setup",
  },
  // Maintenance
  {
    id: "water-changes",
    question: "How often do I need to change the water?",
    answer:
      "With the built-in filtration and UV system, most users change water every 2–4 weeks depending on usage. The filter cartridge should be replaced every 3–6 months.",
    category: "Maintenance",
  },
  {
    id: "filter-replacement",
    question: "How do I replace the filter?",
    answer:
      "The filter cartridge is easily accessible and can be replaced in minutes without tools. Simply open the filter compartment, remove the old cartridge, and insert the new one. Replacement filters are available on our website.",
    category: "Maintenance",
  },
  // Shipping
  {
    id: "shipping-time",
    question: "How long does shipping take?",
    answer:
      "Standard delivery takes 5–10 business days for the V1 and 7–14 business days for the V1 Pro. White-glove delivery is available for the V1 Pro, which includes room-of-choice placement and packaging removal.",
    category: "Shipping",
  },
  {
    id: "shipping-cost",
    question: "Is shipping included in the price?",
    answer:
      "Yes. Freight shipping within the contiguous United States is included in the product price. White-glove delivery options may vary by location.",
    category: "Shipping",
  },
  {
    id: "international-shipping",
    question: "Do you ship internationally?",
    answer:
      "We currently ship within the contiguous United States. International shipping is not available at this time.",
    category: "Shipping",
  },
  // Warranty & Returns
  {
    id: "warranty-coverage",
    question: "What does the warranty cover?",
    answer:
      "The V1 includes a 1-year manufacturer warranty. The V1 Pro includes a 2-year warranty. Coverage includes manufacturing defects in the tub, chiller, filtration system, and structural components.",
    category: "Warranty",
  },
  {
    id: "return-policy",
    question: "What is your return policy?",
    answer:
      "We offer a 30-day return window from the date of delivery. The product must be in its original condition. Return shipping for large items may apply. See our Returns page for full details.",
    category: "Returns",
  },
  // Payments
  {
    id: "payment-methods",
    question: "What payment methods do you accept?",
    answer:
      "We accept bank transfers and manual payment requests. After placing your order, you'll receive instructions for your selected payment method. Payment is verified manually before your order is processed.",
    category: "Payments",
  },
  {
    id: "payment-process",
    question: "How does payment verification work?",
    answer:
      "After you place an order, our team manually verifies your payment. For bank transfers, you can upload payment proof for faster processing. For payment requests, we'll email you a secure payment link.",
    category: "Payments",
  },
];

export const faqCategories = [...new Set(faqData.map((f) => f.category))];
